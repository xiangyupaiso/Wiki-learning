import { useState, useCallback } from 'react';
import { Home, Info, ChevronLeft, Lightbulb } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { experiment1 } from '@/data/experiments';
import { StepIndicator } from '@/components/StepIndicator';
import { InfoPanel } from '@/components/InfoPanel';

interface ExperimentPageProps {
  onBack: () => void;
  onHome: () => void;
}

// 器材的初始位置
const initialPositions: Record<string, { x: number; y: number }> = {
  freezer: { x: 3, y: 10 },
  incubator: { x: 85, y: 10 },
  'ice-box': { x: 15, y: 30 },
  'alcohol-lamp': { x: 38, y: 35 },
  tube: { x: 22, y: 50 },
  'inoculation-loop': { x: 50, y: 45 },
  'petri-dish': { x: 68, y: 32 },
};

// 计算指定步骤完成后各器材的位置
function getPositionsForStep(stepIndex: number): Record<string, { x: number; y: number }> {
  const positions = { ...initialPositions };
  
  for (let i = 0; i < stepIndex; i++) {
    const step = experiment1.steps[i];
    switch (step.id) {
      case 1:
        positions.tube = { x: 20, y: 38 };
        break;
      case 2:
        positions['inoculation-loop'] = { x: 22, y: 52 };
        break;
      case 3:
        positions['inoculation-loop'] = { x: 62, y: 42 };
        break;
      case 4:
        positions['inoculation-loop'] = { x: 38, y: 35 };
        break;
      case 5:
        positions['inoculation-loop'] = { x: 62, y: 42 };
        break;
      case 6:
        positions['petri-dish'] = { x: 85, y: 25 };
        break;
    }
  }
  
  return positions;
}

export function ExperimentPage({ onBack, onHome }: ExperimentPageProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [showInfo, setShowInfo] = useState(true);
  
  const [isAnimating, setIsAnimating] = useState(false);
  const [movingItem, setMovingItem] = useState<string | null>(null);
  const [itemPositions, setItemPositions] = useState(initialPositions);
  const [showHeatedLoop, setShowHeatedLoop] = useState(false);
  const [showStreakLines, setShowStreakLines] = useState(false);
  const [showBacteria, setShowBacteria] = useState(false);

  const currentStepData = experiment1.steps[currentStep];
  const isCompleted = currentStep >= experiment1.steps.length;

  // 跳转到指定步骤
  const goToStep = useCallback((stepIndex: number) => {
    if (isAnimating) return;
    
    const newPositions = getPositionsForStep(stepIndex);
    setItemPositions(newPositions);
    setCurrentStep(stepIndex);
    
    const newCompletedSteps: number[] = [];
    for (let i = 0; i < stepIndex; i++) {
      newCompletedSteps.push(i);
    }
    setCompletedSteps(newCompletedSteps);
    
    setShowHeatedLoop(false);
    setShowStreakLines(false);
    setShowBacteria(stepIndex >= 7);
  }, [isAnimating]);

  // 执行步骤动画
  const executeStepAnimation = useCallback((stepIndex: number) => {
    const step = experiment1.steps[stepIndex];
    setIsAnimating(true);

    switch (step.id) {
      case 1:
        setMovingItem('tube');
        setTimeout(() => {
          setItemPositions(prev => ({ ...prev, tube: { x: 20, y: 38 } }));
        }, 100);
        setTimeout(() => {
          setMovingItem(null);
          setIsAnimating(false);
          setCompletedSteps(prev => [...prev, stepIndex]);
          setCurrentStep(stepIndex + 1);
        }, 1500);
        break;

      case 2:
        setMovingItem('inoculation-loop');
        setTimeout(() => {
          setItemPositions(prev => ({ ...prev, 'inoculation-loop': { x: 22, y: 52 } }));
        }, 100);
        setTimeout(() => {
          setMovingItem(null);
          setIsAnimating(false);
          setCompletedSteps(prev => [...prev, stepIndex]);
          setCurrentStep(stepIndex + 1);
        }, 1500);
        break;

      case 3:
        setMovingItem('inoculation-loop');
        setTimeout(() => {
          setItemPositions(prev => ({ ...prev, 'inoculation-loop': { x: 62, y: 42 } }));
        }, 100);
        setTimeout(() => { setShowStreakLines(true); }, 800);
        setTimeout(() => {
          setShowStreakLines(false);
          setMovingItem(null);
          setIsAnimating(false);
          setCompletedSteps(prev => [...prev, stepIndex]);
          setCurrentStep(stepIndex + 1);
        }, 2000);
        break;

      case 4:
        setMovingItem('inoculation-loop');
        setTimeout(() => {
          setItemPositions(prev => ({ ...prev, 'inoculation-loop': { x: 38, y: 35 } }));
        }, 100);
        setTimeout(() => { setShowHeatedLoop(true); }, 800);
        setTimeout(() => {
          setShowHeatedLoop(false);
          setMovingItem(null);
          setIsAnimating(false);
          setCompletedSteps(prev => [...prev, stepIndex]);
          setCurrentStep(stepIndex + 1);
        }, 2000);
        break;

      case 5:
        setMovingItem('inoculation-loop');
        setTimeout(() => {
          setItemPositions(prev => ({ ...prev, 'inoculation-loop': { x: 62, y: 42 } }));
        }, 100);
        setTimeout(() => { setShowStreakLines(true); }, 800);
        setTimeout(() => {
          setShowStreakLines(false);
          setMovingItem(null);
          setIsAnimating(false);
          setCompletedSteps(prev => [...prev, stepIndex]);
          setCurrentStep(stepIndex + 1);
        }, 2000);
        break;

      case 6:
        setMovingItem('petri-dish');
        setTimeout(() => {
          setItemPositions(prev => ({ ...prev, 'petri-dish': { x: 85, y: 25 } }));
        }, 100);
        setTimeout(() => {
          setMovingItem(null);
          setIsAnimating(false);
          setCompletedSteps(prev => [...prev, stepIndex]);
          setCurrentStep(stepIndex + 1);
        }, 1500);
        break;

      case 7:
        setTimeout(() => { setShowBacteria(true); }, 1500);
        setTimeout(() => {
          setIsAnimating(false);
          setCompletedSteps(prev => [...prev, stepIndex]);
          setCurrentStep(stepIndex + 1);
        }, 3000);
        break;
    }
  }, []);

  // 处理器材点击
  const handleItemClick = useCallback((itemId: string) => {
    if (isAnimating || !currentStepData) return;
    if (currentStepData.highlightItems.includes(itemId)) {
      executeStepAnimation(currentStep);
    }
  }, [currentStep, currentStepData, isAnimating, executeStepAnimation]);

  // 检查器材是否应该高亮
  const isItemHighlighted = useCallback((itemId: string) => {
    if (isAnimating || !currentStepData) return false;
    return currentStepData.highlightItems.includes(itemId);
  }, [currentStepData, isAnimating]);

  // 重置实验
  const resetExperiment = () => {
    setCurrentStep(0);
    setCompletedSteps([]);
    setItemPositions(initialPositions);
    setShowHeatedLoop(false);
    setShowStreakLines(false);
    setShowBacteria(false);
    setIsAnimating(false);
    setMovingItem(null);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden bg-background">
      {/* 顶部导航 */}
      <header className="h-12 bg-card/90 backdrop-blur-sm border-b border-border flex items-center justify-between px-3 z-20 shrink-0">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={onBack} className="shrink-0 h-7 w-7">
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <div className="h-4 w-px bg-border" />
          <div>
            <h1 className="font-semibold text-xs md:text-sm truncate max-w-[150px] md:max-w-md">
              实验1：大肠杆菌 DH5α 复苏
            </h1>
          </div>
        </div>
        
        <div className="flex items-center gap-1">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={() => setShowInfo(!showInfo)}
            className={`h-7 text-xs ${showInfo ? 'bg-primary/20' : ''}`}
          >
            <Info className="w-3.5 h-3.5 mr-1" />
            <span className="hidden sm:inline">信息</span>
          </Button>
          <Button variant="ghost" size="icon" onClick={onHome} className="h-7 w-7">
            <Home className="w-4 h-4" />
          </Button>
        </div>
      </header>

      {/* 主内容区 */}
      <div className="flex-1 flex overflow-hidden">
        {/* 左侧边栏 */}
        <aside className="hidden lg:flex flex-col w-64 p-2 gap-2 shrink-0">
          {currentStepData && !isCompleted && (
            <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-2.5 animate-fade-in shrink-0">
              <div className="flex items-center gap-1.5 mb-1.5">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-xs text-amber-400 font-medium">
                  步骤 {currentStep + 1}/{experiment1.steps.length}
                </span>
              </div>
              <h3 className="font-semibold text-xs mb-1">{currentStepData.title}</h3>
              <p className="text-[11px] text-foreground/80 leading-relaxed">{currentStepData.description}</p>
              <p className="text-[10px] text-amber-400 mt-1.5">点击高亮的器材</p>
            </div>
          )}
          
          <div className="flex-1 overflow-hidden min-h-0">
            <StepIndicator
              steps={experiment1.steps}
              currentStep={currentStep}
              completedSteps={completedSteps}
              onStepClick={goToStep}
            />
          </div>
        </aside>

        {/* 中央实验区域 */}
        <main className="flex-1 relative overflow-hidden">
          {/* 超净台背景 */}
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{ backgroundImage: `url('/images/laminar-hood.jpg')` }}
          />
          
          {/* 器材层 */}
          <div className="absolute inset-0 z-10">
            {experiment1.items.map((item) => {
              const position = itemPositions[item.id];
              const isHighlighted = isItemHighlighted(item.id);
              const isMoving = movingItem === item.id;
              
              return (
                <div
                  key={item.id}
                  className={`
                    absolute cursor-pointer
                    ${isHighlighted ? 'z-50' : 'z-10'}
                    ${isAnimating && !isHighlighted ? 'opacity-40' : 'opacity-100'}
                  `}
                  style={{
                    left: `${position.x}%`,
                    top: `${position.y}%`,
                    width: `${item.size.width}px`,
                    height: `${item.size.height}px`,
                    transition: isMoving ? 'all 1s ease-in-out' : 'all 0.3s ease',
                  }}
                  onClick={() => handleItemClick(item.id)}
                >
                  {/* 高亮效果 */}
                  {isHighlighted && (
                    <div className="absolute -inset-2 rounded-xl border-2 border-amber-400 animate-pulse-glow pointer-events-none" />
                  )}
                  
                  {/* 器材图片 */}
                  <div className="relative w-full h-full flex items-center justify-center">
                    <img
                      src={item.image}
                      alt={item.name}
                      className={`
                        w-full h-full object-contain
                        ${isHighlighted ? 'drop-shadow-[0_0_15px_rgba(251,191,36,0.8)]' : 'drop-shadow-lg'}
                      `}
                      draggable={false}
                    />
                    
                    {/* 灼烧效果 */}
                    {item.id === 'inoculation-loop' && showHeatedLoop && (
                      <div className="absolute inset-0 bg-red-500/50 blur-md rounded-full animate-pulse" />
                    )}
                  </div>
                  
                  {/* 器材标签 */}
                  <div className={`
                    absolute -bottom-5 left-1/2 -translate-x-1/2 whitespace-nowrap
                    text-[10px] font-medium px-2 py-0.5 rounded-full
                    ${isHighlighted ? 'bg-amber-500 text-black' : 'bg-black/70 text-white'}
                  `}>
                    {item.name}
                  </div>
                </div>
              );
            })}
            
            {/* 划线动画 */}
            {showStreakLines && (
              <svg className="absolute inset-0 w-full h-full pointer-events-none z-40">
                <path
                  d="M 68% 38% Q 72% 36%, 75% 38% T 78% 40%"
                  fill="none"
                  stroke="rgba(100, 200, 100, 0.8)"
                  strokeWidth="3"
                  strokeDasharray="8,4"
                  className="animate-pulse"
                />
              </svg>
            )}
            
            {/* 菌落生长 */}
            {showBacteria && (
              <div className="absolute left-[87%] top-[22%] w-14 h-14 pointer-events-none z-30">
                <div className="w-full h-full rounded-full bg-green-400/50 animate-pulse" />
                <div className="absolute inset-2 rounded-full bg-green-300/60" />
              </div>
            )}
          </div>

          {/* 移动端步骤提示 */}
          <div className="lg:hidden absolute top-2 left-2 right-2 z-20">
            {currentStepData && !isCompleted && !isAnimating && (
              <div className="bg-card/95 backdrop-blur-sm border border-amber-500/50 rounded-lg p-2.5 animate-fade-in">
                <div className="flex items-center gap-1.5 mb-1">
                  <Lightbulb className="w-3 h-3 text-amber-400" />
                  <span className="text-[10px] text-amber-400 font-medium">
                    步骤 {currentStep + 1}/{experiment1.steps.length}
                  </span>
                </div>
                <p className="text-xs font-medium">{currentStepData.title}</p>
              </div>
            )}
          </div>

          {/* 动画状态提示 */}
          {isAnimating && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-30">
              <div className="bg-black/80 text-white px-4 py-2 rounded-full text-sm animate-pulse">
                {currentStepData?.title}...
              </div>
            </div>
          )}

          {/* 完成提示 */}
          {isCompleted && (
            <div className="absolute inset-0 z-40 flex items-center justify-center bg-black/70 backdrop-blur-sm animate-fade-in">
              <div className="bg-card border border-border rounded-xl p-5 text-center max-w-xs mx-4">
                <div className="w-14 h-14 rounded-full bg-green-500/20 flex items-center justify-center mx-auto mb-3">
                  <svg className="w-7 h-7 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <h2 className="text-lg font-bold mb-1">实验完成!</h2>
                <p className="text-xs text-muted-foreground mb-4">
                  恭喜完成大肠杆菌 DH5α 复苏实验
                </p>
                <div className="flex gap-2 justify-center">
                  <Button variant="outline" size="sm" onClick={resetExperiment}>
                    重新开始
                  </Button>
                  <Button size="sm" onClick={onBack}>
                    返回目录
                  </Button>
                </div>
              </div>
            </div>
          )}
        </main>

        {/* 右侧信息面板 */}
        {showInfo && (
          <aside className="hidden xl:block w-72 p-2 shrink-0">
            <InfoPanel onClose={() => setShowInfo(false)} />
          </aside>
        )}
      </div>
    </div>
  );
}
